create user if not exists 'webclient'@'127.0.0.1' identified by 'secret';
grant select, insert on cybr1100.* to 'webclient'@'127.0.0.1';
flush privileges;

create database if not exists cybr1100;
use cybr1100;

drop table if exists `messages`;
create table messages (
	msg_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	name VARCHAR(128),
	subject VARCHAR(128),
	message VARCHAR(256),
	PRIMARY KEY (msg_id));

drop table if exists `users`;
create table users (
	user_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	username VARCHAR(128),
	password VARCHAR(128),
	PRIMARY KEY(user_id));

insert into users (username, password) values ('admin', 'cyber');
